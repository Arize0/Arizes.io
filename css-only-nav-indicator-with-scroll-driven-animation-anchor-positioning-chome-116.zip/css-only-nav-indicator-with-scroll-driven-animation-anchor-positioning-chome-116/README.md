# CSS Only Nav Indicator with Scroll Driven Animation && Anchor Positioning ✨ [Chome 116+]

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/ExOMvwW](https://codepen.io/jh3y/pen/ExOMvwW).

